
package edu.iastate.cs228.hw5;

import java.util.Iterator;

import edu.iastate.cs228.hw5.api.ListGraph;

/**
 * Graph implementation based on adjacency lists.
 */
public class ListGraphImpl<E> implements ListGraph<E>
{

  @Override
  public boolean addEdge(E u, E v, int weight)
  {
    // TODO Auto-generated method stub
    return false;
  }

  @Override
  public boolean addVertex(E vertex)
  {
    // TODO Auto-generated method stub
    return false;
  }

  @Override
  public Iterator<E> vertices()
  {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public Iterator<edu.iastate.cs228.hw5.api.Graph.Edge<E>> getNeighbors(E vertex)
  {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public int h(E current, E goal)
  {
    // TODO Auto-generated method stub
    return 0;
  }
}
