
package edu.iastate.cs228.hw5;

import edu.iastate.cs228.hw5.api.BidirectionalGraphAnimation;
import edu.iastate.cs228.hw5.api.Graph;
import edu.iastate.cs228.hw5.api.GraphAnimation;
import edu.iastate.cs228.hw5.api.PathFinderFactory;

/**
 * TODO: DESCRIBE YOUR IMPLEMENTATION CHOICES HERE
 */
public class PathFinderFactoryImpl implements PathFinderFactory
{

  @Override
  public <E> GraphAnimation<E> createAStarFinder(Graph<E> graph, E start, E goal)
  {
    // TODO
    throw new UnsupportedOperationException("TODO: This method has not been implemented yet!");
  }

  @Override
  public <E> GraphAnimation<E> createBFSFinder(Graph<E> graph, E start, E goal)
  {
    return new BFSFinder<E>(graph, start, goal);
  }

  @Override
  public <E> GraphAnimation<E> createDFSFinder(Graph<E> graph, E start, E goal)
  {
    // TODO
    throw new UnsupportedOperationException("TODO: This method has not been implemented yet!");
  }

  @Override
  public <E> GraphAnimation<E> createDijkstraFinder(Graph<E> graph, E start,
      E goal)
  {
    // TODO
    throw new UnsupportedOperationException("TODO: This method has not been implemented yet!");
  }

  @Override
  public <E> BidirectionalGraphAnimation<E> createBidirectionalAStarFinder(
      Graph<E> graph, E start, E goal)
  {
    // TODO
    throw new UnsupportedOperationException("TODO: This method has not been implemented yet!");
  }

  @Override
  public <E> BidirectionalGraphAnimation<E> createBidirectionalBFSFinder(
      Graph<E> graph, E start, E goal)
  {
    // TODO
    throw new UnsupportedOperationException("TODO: This method has not been implemented yet!");
  }

  @Override
  public <E> BidirectionalGraphAnimation<E> createBidirectionalDFSFinder(
      Graph<E> graph, E start, E goal)
  {
    // TODO
    throw new UnsupportedOperationException("TODO: This method has not been implemented yet!");
  }

  @Override
  public <E> BidirectionalGraphAnimation<E> createBidirectionalDijkstraFinder(
      Graph<E> graph, E start, E goal)
  {
    // TODO
    throw new UnsupportedOperationException("TODO: This method has not been implemented yet!");
  }

}
