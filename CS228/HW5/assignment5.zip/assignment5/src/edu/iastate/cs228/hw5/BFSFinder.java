package edu.iastate.cs228.hw5;

import java.util.Collection;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import edu.iastate.cs228.hw5.api.Graph;
import edu.iastate.cs228.hw5.api.GraphAnimation;
import edu.iastate.cs228.hw5.api.Graph.Edge;

/**
 * Sample implementation of GraphAnimation based on breadth-first
 * search.
 */
public class BFSFinder<E> implements GraphAnimation<E>
{
  /**
   * The graph to be traversed.
   */
  private Graph<E> graph;
  
  /**
   * The start node vertex.
   */
  private E start;
  
  /**
   * The goal vertex (may be null).
   */
  private E goal;
  
  /**
   * The open set (used as a FIFO queue).
   */
  private Deque<E> openSet = new LinkedList<E>();
  
  /**
   * Predecessors of nodes discovered in the search.  Each node
   * in the open set or closed set has an entry in this map.
   * (The predecessor of the start node is null.)
   */
  private Map<E, E> predMap = new HashMap<E, E>();
  
  /**
   * Vertices in the closed set.
   */
  private Set<E> closedSet = new HashSet<E>();
  
  /**
   * Flag indicating that the algorithm has terminated, either
   * by finding a goal node or by visiting all nodes reachable
   * from the start.
   */
  private boolean done = false;
  
  /**
   * Constructs a BFSFinder for the given graph and the
   * given start and goal nodes.  The goal may be null.
   * @param graph the graph to be searched
   * @param start the start node
   * @param goal the goal node
   */
  public BFSFinder(Graph<E> graph, E start, E goal)
  {
    this.graph = graph;
    this.start = start;
    this.goal = goal;
    openSet.add(start);
    predMap.put(start, null);
  }
  
  @Override
  public Collection<E> closedSet()
  {
    return Collections.unmodifiableCollection(closedSet);
  }

  @Override
  public boolean done()
  {
    return done;
  }

  @Override
  public List<E> getPath(E vertex)
  {
    E current = vertex;
    List<E> path = new LinkedList<E>();
    path.add(current);
    E pred = null;
    while ((pred = predMap.get(current)) != null)
    {
      path.add(0, pred);
      current = pred;
    }
    if (start.equals(path.get(0)))
    {
      return path;
    }
    else
    {
      // vertex is not reachable, return empty list
      return new LinkedList<E>();
    }
  }
  
  @Override
  public E getPredecessor(E vertex)
  {
    return predMap.get(vertex);
  }

  @Override
  public Iterator<E> openSet()
  {
    // Wrap the open set in a read-only view
    return Collections.unmodifiableCollection(openSet).iterator();
  }

  @Override
  public E step()
  {
    if (openSet.isEmpty()) done = true;
    if (done) return null;
    E current = openSet.remove();
    closedSet.add(current);
    if (current.equals(goal))
    {
      done = true;
      return current;
    }
    Iterator<Edge<E>> iter = graph.getNeighbors(current);
    while (iter.hasNext())
    {
      E neighbor = iter.next().vertex;
      if (!neighbor.equals(start) && predMap.get(neighbor) == null)
      {
        openSet.add(neighbor);
        predMap.put(neighbor, current);
      }
    }
    return current;
  }

  /**
   * Since the algorithm does not maintain a distance map, this
   * method always returns 0 for reachable vertices.
   */
  @Override
  public int getDistance(E vertex)
  {
    List<E> path = getPath(vertex);
    if (path.size() == 0)
    {
      return -1;
    }
    return 0;
  }

}
