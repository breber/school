package edu.iastate.cs228.hw2;
import java.util.Comparator;

/**
 * This class encapsulates the configuration and instrumentation for a 
 * sorting utility based on the quicksort algorithm.
 */
public class QuickSorter<T>
{ 
  /**
   * Constructs a QuickSorter that will sort an array in ascending order according
   * to the given Comparator, using the default pivot selection strategy.
   * @param comp Comparator to use for sorting
   */
  public QuickSorter(Comparator<T> comp)
  {
    // TODO
  }
  
  /**
   * Constructs a QuickSorter that will sort an array in ascending order according
   * to the given Comparator, using the given pivot selection strategy.
   * @param comp Comparator to use for sorting
   * @param strategy the pivot selection strategy
   */
  public QuickSorter(Comparator<T> comp, IPivotStrategy<T> strategy)
  {
    // TODO
  }
  
  /**
   * Sorts the given array using the quicksort algorithm.
   * @param arr array to be sorted
   */
  public void sort(T[] arr)
  {
    quickSortRec(arr, 0, arr.length - 1, 1);
  }

  /**
   * Returns the maximum depth of recursion for the most recent
   * call to sort().
   * @return maximum depth of recursion
   */
  public int getMaxDepth()
  {
    // TODO
    return 0;
  }
  
  /**
   * Returns the number of comparisons of array elements performed during
   * the most recent call to sort().
   * @return number of comparisons performed
   */
  public int getComparisons()
  {
    // TODO
    return 0;
  }
  
  /**
   * Returns the number of exchanges of array elements performed during the
   * most recent call to sort().  This value includes an approximation
   * of the number of exchanges performed during insertion sort operations.
   * @return number of exchanges of array elements
   */
  public int getSwaps()
  {
    // TODO
    return 0;
  }
  
  /**
   * Sets this sorter to use three-way partitioning.
   * @param useThreeWayPartition true to use three-way partitioning, 
   *   false to use normal partitioning
   */
  public void setUseThreeWay(boolean useThreeWayPartition)
  {
    // TODO
  }
  
  /**
   * Returns true if this sorter is currently configured to use
   * three-way partitioning, false otherwise.
   * @return true if three-way partitioning is being used, false otherwise
   */
  public boolean getUseThreeWay()
  {
    // TODO
    return false;
  }
  
  /**
   * Sorts the subarray consisting of positions first through last.
   * @param arr array to be sorted
   * @param first index of first position in subarray
   * @param last index of last position in subarray
   * @param depth depth of recursion prior to this call
   */
  private void quickSortRec(T[] arr, int first, int last, int depth)
  {
    // TODO
  }
  
}
