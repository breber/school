package edu.iastate.cs228.hw2;
import java.util.Comparator;

/**
 * Utilities for sorting arrays of objects using the insertion
 * sort algorithm.
 */
public class SortUtil
{
  /**
   * Sorts the given array using the insertion sort algorithm. 
   * The array is sorted in ascending order according to the given 
   * Comparator.
   * @param arr the array to be sorted
   * @param comp the Comparator to use for ordering
   */
  public static <T> void insertionSort(T[] arr, Comparator< ? super T> comp)
  {
    // TODO
  }

  /**
   * Sorts the given array using the insertion sort algorithm.
   * The array is sorted in ascending order according to the 
   * natural ordering of type T.
   * @param arr the array to be sorted
   */
  public static <T extends Comparable< ? super T>> void insertionSort(T[] arr)
  {
    // TODO
  }

  /**
   * Sorts the subarray between first and last (inclusive) 
   * using the insertion sort algorithm.  The subarray
   * is sorted in ascending order according to the given Comparator.
   * @param arr the array to be sorted
   * @param comp the Comparator to use for ordering
   * @return the number of comparisons of array elements
   *   performed during this call
   */
  public static <T> int insertionSort(T[] arr, int first, int last,
      Comparator< ? super T> comp)
  {
    // TODO
    return 0;
  }

}
