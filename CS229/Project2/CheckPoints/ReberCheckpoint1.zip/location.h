/**
 * object.h
 *
 * @author Brian Reber
 *
 * An abstract Object class, containing information applicable to 
 * all types of objects
 */
#ifndef LOCATION_H
#define LOCATION_H

#include <string>

using namespace std;

class Location {
	private:
		bool probable;
		string type;
		string display;
		int xloc;
		int yloc;
	public: 
		/**
		 * Creates a new object with the given type
		 *
		 * @param _type - the type of the object
		 */
		Location(string _type) {
			type = _type;
			xloc = -1;
			yloc = -1;
		}
	
		/**
		 * Provice a virtual Deconstructor to allow for the virtual method
		 */
		virtual ~Location() {	}
	
		/**
		 * Gets whether this object is probable or not
		 *
		 * @return whether this object is probable or not
		 */
		bool isProbable() const {
			return probable;
		}

		/**
		 * Sets the whether this object is probable
		 *
		 * @param prob - whether this object is probable
		 */
		void setProbable(bool prob);
	
		/**
		 * Gets the display string of this object
		 *
		 * @return the display string of this object
		 */
		string getDisplay() const {
			return display;
		}
	
		/**
		 * Sets the display string of this object
		 *
		 * @param disp - the display string of this object
		 */
		void setDisplay(string disp);
	
		/**
		 * Gets the x location of this object
		 *
		 * @return the x location of this object
		 */
		int getXLoc() const {
			return xloc;
		}
	
		/**
		 * Sets the x location of this object
		 *
		 * @param loc - the x location of this object
		 */
		void setXLoc(int loc);
	
		/**
		 * Gets the x location of this object
		 *
		 * @return the x location of this object
		 */
		int getYLoc() const {
			return yloc;
		}
	
		/**
		 * Sets the y location of this object
		 *
		 * @param loc - the y location of this object
		 */
		void setYLoc(int loc);
	
		/**
		 * Gets the type of this object
		 *
		 * @return the type of this object
		 */
		string getType() const {
			return type;
		}
	
		/**
		 * Returns a string representation of this object
		 *
		 * @return a string representation of this object
		 */
		virtual string toString() const;
};

#endif
