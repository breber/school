/**
 * stringutils.h
 *
 * @author Brian Reber
 *
 * Provides some functions for parsing strings into Objects/Simulations/Properties
 */
#ifndef STRINGUTILS_H
#define STRINGUTILS_H

#include <string>
#include <queue>
#include "simulation.h"

#include "property.h"
#include "lava.h"
#include "water.h"
#include "mud.h"
#include "hole.h"
#include "fog.h"
#include "jammer.h"

#include "object.h"
#include "robot.h"
#include "earthrock.h"
#include "romulanrock.h"
#include "ball.h"
#include "block.h"
#include "energypill.h"


using namespace std;

/*
 * Removes "//" comments from the given string
 *
 * @param str - the string to remove comments from
 * @return the string without comments
 */
string removeComments(string str);

/*
 * Trims trailing whitespace.
 *
 * @param str - the string to remove trailing whitespace from
 * @return the string without trailing whitespace
 */
string trim(string str);

/*
 * Converts the given string to upper case
 *
 * @param str - the string to convert to upper case
 * @return the string in all caps
 */
string toUpperCase(string str);

/*
 * Parses the simulation element from the queue of string values
 * 
 * @param *sim - the Simulation to set the values for
 * @param *values - the queue containing the lines of the config file
 */
void parseSimulation(Simulation *sim, queue<string> *values);

/*
 * Parses an object element from the queue of string values
 * 
 * @param *values - the queue containing the lines of the config file
 * @return a pointer to an Object representation of the object element
 */
Object * parseObject(queue<string> *values);

/*
 * Parses a property element from the queue of string values
 * 
 * @param *values - the queue containing the lines of the config file
 * @return a pointer to a Property representation of the property element
 */
Property * parseProperty(queue<string> *values);

#endif
