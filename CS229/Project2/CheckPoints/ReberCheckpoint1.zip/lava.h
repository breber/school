/**
 * lava.h
 *
 * @author Brian Reber
 *
 * A Lava class, containing all the Lava specific information.
 */
#ifndef LAVA_H
#define LAVA_H

#include <string>
#include "property.h"
#include <list>

using namespace std;

class Lava : public Property {
	private:
		string name;
		int energyCost;
	
		bool nameDef;
	public: 
		/**
		 * Creates a lava with all the parameters in the given
		 * list.
		 * 
		 * @param params - a list of parameters according to the
		 *			given spec.
		 */
		Lava(list<string> params);
	
		/**
		 * Gets the name of this lava
		 *
		 * @return the name of this lava
		 */
		string getName() const {
			return name;
		}
		
		/**
		 * Sets the name of this lava
		 *
		 * @param the name of this lava
		 */
		void setName(string nam);
	
		/**
		 * Gets the energy cost of this lava
		 *
		 * @return the energy cost of this lava
		 */
		int getEnergyCost() const {
			return energyCost;
		}
		
		/**
		 * Sets the energy cost of this lava
		 *
		 * @param the energy cost of this lava
		 */
		void setEnergyCost(int en_cost);
	
		/**
		 * Returns a string representation of this object
		 *
		 * @return a string representation of this object
		 */
		string toString() const;
};

#endif
