/**
 * simulation.cpp
 *
 * @author Brian Reber
 *
 * An class representing the simulation board
 */
#include "simulation.h"
#include <iostream>
#include <sstream>

/**
 * Creates a new default simulation
 */
Simulation::Simulation() {
	initializedObjects = false;
	width = -1;
	height = -1;
}

/**
 * Sets the width of the simulation board
 *
 * @param _width - the width of the simulation board
 */
void Simulation::setWidth(int _width) {
	if (_width > 0 && _width <= 35) {
		width = _width;
	}
}

/**
 * Sets the height of the simulation board
 *
 * @param _height - the height of the simulation board
 */
void Simulation::setHeight(int _height) {
	if (_height > 0 && _height <= 35) {
		height = _height;
	}
}

/**
 * Initializes the objects array
 */
void Simulation::initializeArrays() {
	objects = new Object* *[width];
	properties = new vector<Property*> *[width];
	
	for (int i = 0; i < width; i++) {
		objects[i] = new Object*[height];
		properties[i] = new vector<Property*>[height];
		
		for (int j = 0; j < height; j++) {
			objects[i][j] = NULL;
		}
	}
	
	initializedObjects = true;
}

/**
 * Adds the given object to this simulation
 *
 * @param the object to add
 */
void Simulation::addObject(Object *obj) {
	int x = (*obj).getXLoc();
	int y = (*obj).getYLoc();
	
	if (!initializedObjects && width > 0 && height > 0) {
		initializeArrays();
	} else if (width < 0 || height < 0) {
		cerr << "Must initialize height and width before adding an object" << endl;
		return;
	}
	
	objects[x][y] = obj;
}

/**
 * Adds the given property to this simulation
 *
 * @param the property to add
 */
void Simulation::addProperty(Property *prop) {
	int x = (*prop).getXLoc();
	int y = (*prop).getYLoc();
	
	if (!initializedObjects && width > 0 && height > 0) {
		initializeArrays();
	} else if (width < 0 || height < 0) {
		cerr << "Must initialize height and width before adding a property" << endl;
		return;
	}
	
	properties[x][y].push_back(prop);
}

/**
 * Prints out the necessary object data
 *
 * @return the string representation of all the objects in the simulation
 */
string Simulation::printObjectData() const {
	stringstream out;
	
	for (int y = 0; y < height; y++) {
		for (int x = 0; x < width; x++) {
			bool printedLoc = false;
			
			if (objects[x][y] != NULL) {
				out << "Location: " << (*objects[x][y]).getXLoc() << ", " << (*objects[x][y]).getYLoc() << endl;
				out << (*objects[x][y]).toString();
				
				printedLoc = true;
			}
			
			if (properties[x][y].size() > 0) {
				if (!printedLoc) {
					out << "Location: " << (*(properties[x][y])[0]).getXLoc() << ", " << (*(properties[x][y])[0]).getYLoc() << endl;
					printedLoc = true;
				}
				for (unsigned int i = 0; i < properties[x][y].size(); i++) {
					out << (*(properties[x][y])[i]).toString();
				}
			}
			
			if (printedLoc) {
				out << endl;
			}
		}
	}
	
	return out.str();
}

/**
 * Returns a string representation of this simulation
 *
 * @param a string representation of this simulation
 */
string Simulation::toString() const {
	stringstream out;
	
	for (int y = 0; y < height; y++) {
		for (int x = 0; x < width; x++) {
			if (objects[x][y] != NULL) {
				out << (*objects[x][y]).getDisplay();
			} else {
				out << "__";
			}
			
			if (properties[x][y].size() == 1) {
				out << (*(properties[x][y])[0]).getDisplay();
			} else if (properties[x][y].size() > 1) {
				out << "XX";
			} else {
				out << "__";
			} 
			
			out << " ";
		}
		out << endl;
	}
	
	return out.str();
}
