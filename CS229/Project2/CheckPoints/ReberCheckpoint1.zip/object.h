/**
 * object.h
 *
 * @author Brian Reber
 *
 * An abstract Object class, containing information applicable to 
 * all types of objects
 */
#ifndef OBJECT_H
#define OBJECT_H

#include <string>
#include "location.h"

using namespace std;

class Object : public Location {
	private:
		bool movable;
	public: 
		/**
		 * Creates a new object with the given type
		 *
		 * @param _type - the type of the object
		 */
		Object(string _type) : Location (_type) {	}
		
		/**
		 * Provice a virtual Deconstructor to allow for the virtual method
		 */
		virtual ~Object() { }
	
		/**
		 * Gets whether this object is movable or not
		 *
		 * @return whether this object is movable or not
		 */
		bool isMovable() const {
			return movable;
		}
	
		/**
		 * Sets the whether this object is movable
		 *
		 * @param mov - whether this object is movable
		 */
		void setMovable(bool mov);
	
		/**
		 * Returns a string representation of this object
		 *
		 * @return a string representation of this object
		 */
		virtual string toString() const;
};

#endif
