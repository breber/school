/**
 * fog.h
 *
 * @author Brian Reber
 *
 * A Fog class, containing all the Fog specific information.
 */
#ifndef FOG_H
#define FOG_H

#include <string>
#include "property.h"
#include <list>

using namespace std;

class Fog : public Property {
	private:
		string name;
	
		bool nameDef;
	public: 
		/**
		 * Creates a fog with all the parameters in the given
		 * list.
		 * 
		 * @param params - a list of parameters according to the
		 *			given spec.
		 */
		Fog(list<string> params);
	
		/**
		 * Gets the name of this fog
		 *
		 * @return the name of this fog
		 */
		string getName() const {
			return name;
		}
		
		/**
		 * Sets the name of this fog
		 *
		 * @param the name of this fog
		 */
		void setName(string nam);
	
		/**
		 * Returns a string representation of this object
		 *
		 * @return a string representation of this object
		 */
		string toString() const;
};

#endif
