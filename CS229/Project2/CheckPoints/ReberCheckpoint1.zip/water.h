/**
 * water.h
 *
 * @author Brian Reber
 *
 * A Water class, containing all the Water specific information.
 */
#ifndef WATER_H
#define WATER_H

#include <string>
#include "property.h"
#include <list>

using namespace std;

class Water : public Property {
	private:
		string name;
		int energyCost;
	
		bool nameDef;
	public: 
		/**
		 * Creates a water with all the parameters in the given
		 * list.
		 * 
		 * @param params - a list of parameters according to the
		 *			given spec.
		 */
		Water(list<string> params);
	
		/**
		 * Gets the name of this water
		 *
		 * @return the name of this water
		 */
		string getName() const {
			return name;
		}
		
		/**
		 * Sets the name of this water
		 *
		 * @param the name of this water
		 */
		void setName(string nam);
	
		/**
		 * Gets the energy cost of this water
		 *
		 * @return the energy cost of this water
		 */
		int getEnergyCost() const {
			return energyCost;
		}
		
		/**
		 * Sets the energy cost of this water
		 *
		 * @param the energy cost of this water
		 */
		void setEnergyCost(int en_cost);
	
		/**
		 * Returns a string representation of this object
		 *
		 * @return a string representation of this object
		 */
		string toString() const;
};

#endif
