/**
 * ball.h
 *
 * @author Brian Reber
 *
 * A Ball class, containing all the Ball specific information.
 */
#ifndef BALL_H
#define BALL_H

#include "object.h"
#include <string>
#include <list>

using namespace std;

class Ball : public Object {
	private:
		string color;
		string name;
	
		bool nameDef;
		bool colorDef;
	public:
		/**
		 * Creates a ball with all the parameters in the given
		 * list.
		 * 
		 * @param params - a list of parameters according to the
		 *			given spec.
		 */
		Ball(list<string> params);
		
		/**
		 * Gets the color of this ball
		 *
		 * @return the color of this ball
		 */
		string getColor() const {
			return color;
		}
	
		/**
		 * Sets the color of this ball
		 *
		 * @param the color of this ball
		 */
		void setColor(string col);
	
		/**
		 * Gets the name of this ball
		 *
		 * @return the name of this ball
		 */
		string getName() const {
			return name;
		}
	
		/**
		 * Sets the name of this ball
		 *
		 * @param the name of this ball
		 */
		void setName(string nam);
	
		/**
		 * Returns a string representation of this object
		 *
		 * @return a string representation of this object
		 */
		string toString() const;
};

#endif
