/**
 * earthrock.h
 *
 * @author Brian Reber
 *
 * An Earth Rock class, containing all the Earth Rock specific information.
 */
#ifndef EARTHROCK_H
#define EARTHROCK_H

#include "object.h"
#include <string>
#include <list>

using namespace std;

class EarthRock : public Object {
	private:
		string color;
		string name;
	
		bool nameDef;
		bool colorDef;
	public:
		/**
		 * Creates an earth rock with all the parameters in the given
		 * list.
		 * 
		 * @param params - a list of parameters according to the
		 *			given spec.
		 */
		EarthRock(list<string> params);
		
		/**
		 * Gets the color of this earth rock
		 *
		 * @return the color of this earth rock
		 */
		string getColor() const {
			return color;
		}
	
		/**
		 * Sets the color of this earth rock
		 *
		 * @param the color of this earth rock
		 */
		void setColor(string col);
	
		/**
		 * Gets the name of this earth rock
		 *
		 * @return the name of this earth rock
		 */
		string getName() const {
			return name;
		}
	
		/**
		 * Sets the name of this earth rock
		 *
		 * @param the name of this earth rock
		 */
		void setName(string nam);
	
		/**
		 * Returns a string representation of this object
		 *
		 * @return a string representation of this object
		 */
		string toString() const;
};

#endif
