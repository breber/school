/**
 * block.h
 *
 * @author Brian Reber
 *
 * A Block class, containing all the Block specific information.
 */
#ifndef BLOCK_H
#define BLOCK_H

#include "object.h"
#include <string>
#include <list>

using namespace std;

class Block : public Object {
	private:
		string color;
		string name;
	
		bool nameDef;
		bool colorDef;
	public:
		/**
		 * Creates a block with all the parameters in the given
		 * list.
		 * 
		 * @param params - a list of parameters according to the
		 *			given spec.
		 */
		Block(list<string> params);
		
		/**
		 * Gets the color of this block
		 *
		 * @return the color of this block
		 */
		string getColor() const {
			return color;
		}
	
		/**
		 * Sets the color of this block
		 *
		 * @param the color of this block
		 */
		void setColor(string col);
	
		/**
		 * Gets the name of this block
		 *
		 * @return the name of this block
		 */
		string getName() const {
			return name;
		}
	
		/**
		 * Sets the name of this block
		 *
		 * @param the name of this block
		 */
		void setName(string nam);
	
		/**
		 * Returns a string representation of this object
		 *
		 * @return a string representation of this object
		 */
		string toString() const;
};

#endif
