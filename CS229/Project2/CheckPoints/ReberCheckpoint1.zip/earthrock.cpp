/**
 * earthrock.h
 *
 * @author Brian Reber
 *
 * An Earth Rock class, containing all the Earth Rock specific information.
 */
#include "earthrock.h"
#include "stringutils.h"
#include <iostream>
#include <sstream>

/**
 * Creates an earth rock with all the parameters in the given
 * list.
 * 
 * @param params - a list of parameters according to the
 *			given spec.
 */
EarthRock::EarthRock(list<string> params) : Object::Object("Earth Rock") {
	color = "blue";
	name = "Object";
	setProbable(true);
	setMovable(false);
	
	nameDef = false;
	colorDef = false;
	
	while (!params.empty()) {
		string front = params.front();
		string label = front.substr(0, front.find("="));
		string val = trim(front.substr(front.find("=") + 2));

		if (label.find("color") != string::npos) {
			color = val;
			colorDef = true;
		} else if (label.find("name") != string::npos) {
			name = val;
			nameDef = true;
		} else if (label.find("display") != string::npos) {
			if (val.size() != 2) {
				cerr << "Display attribute must be 2 characters" << endl;
				return;
			}
			
			setDisplay(val);
		} else if (label.find("xloc") != string::npos) {
			int xloc;
			stringstream ss(val);
			ss >> xloc;
			setXLoc(xloc);
		} else if (label.find("yloc") != string::npos) {
			int yloc;
			stringstream ss(val);
			ss >> yloc;
			setYLoc(yloc);
		}
		
		params.pop_front();
	}
}

/**
 * Sets the color of this earth rock
 *
 * @param the color of this earth rock
 */
void EarthRock::setColor(string col) {
	color = col;
}

/**
 * Sets the name of this earth rock
 *
 * @param the name of this earth rock
 */
void EarthRock::setName(string nam) {
	name = nam;
}

/**
 * Returns a string representation of this object
 *
 * @return a string representation of this object
 */
string EarthRock::toString() const {
	stringstream str;
	
	str << Object::toString();
	if (nameDef) {
		str << "Name: " << getName() << endl;
	} else {
		str << "Name: " << getDisplay() << endl;
	}
	
	if (colorDef) {
		str << "Color: " << getColor() << endl;
	}
	
	return str.str();
}
