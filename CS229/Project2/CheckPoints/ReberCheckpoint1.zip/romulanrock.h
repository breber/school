/**
 * romulanrock.h
 *
 * @author Brian Reber
 *
 * A Romulan Rock class, containing all the Romulan Rock specific information.
 */
#ifndef ROMULANROCK_H
#define ROMULANROCK_H

#include "object.h"
#include <string>
#include <list>

using namespace std;

class RomulanRock : public Object {
	private:
		string color;
		string name;
	
		bool nameDef;
		bool colorDef;
	public:
		/**
		 * Creates a romulan rock with all the parameters in the given
		 * list.
		 * 
		 * @param params - a list of parameters according to the
		 *			given spec.
		 */
		RomulanRock(list<string> params);
		
		/**
		 * Gets the color of this romulan rock
		 *
		 * @return the color of this romulan rock
		 */
		string getColor() const {
			return color;
		}
	
		/**
		 * Sets the color of this romulan rock
		 *
		 * @param the color of this romulan rock
		 */
		void setColor(string col);
	
		/**
		 * Gets the name of this romulan rock
		 *
		 * @return the name of this romulan rock
		 */
		string getName() const {
			return name;
		}
	
		/**
		 * Sets the name of this romulan rock
		 *
		 * @param the name of this romulan rock
		 */
		void setName(string nam);
	
		/**
		 * Returns a string representation of this object
		 *
		 * @return a string representation of this object
		 */
		string toString() const;
};

#endif
