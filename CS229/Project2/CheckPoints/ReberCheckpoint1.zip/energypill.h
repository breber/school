/**
 * energypill.h
 *
 * @author Brian Reber
 *
 * An Energy Pill class, containing all the Energy Pill specific information.
 */
#ifndef ENERGYPILL_H
#define ENERGYPILL_H

#include "object.h"
#include <string>
#include <list>

using namespace std;

class EnergyPill : public Object {
	private:
		string color;
		string name;
		int energyContents;
	
		bool nameDef;
		bool colorDef;
	public:
		/**
		 * Creates an energy pill with all the parameters in the given
		 * list.
		 * 
		 * @param params - a list of parameters according to the
		 *			given spec.
		 */
		EnergyPill(list<string> params);
		
		/**
		 * Gets the color of this energy pill
		 *
		 * @return the color of this energy pill
		 */
		string getColor() const {
			return color;
		}
	
		/**
		 * Sets the color of this energy pill
		 *
		 * @param the color of this energy pill
		 */
		void setColor(string col);
	
		/**
		 * Gets the name of this energy pill
		 *
		 * @return the name of this energy pill
		 */
		string getName() const {
			return name;
		}
	
		/**
		 * Sets the name of this energy pill
		 *
		 * @param the name of this energy pill
		 */
		void setName(string nam);
	
		/**
		 * Gets the energy contents of this energy pill
		 *
		 * @return the energy contents of this energy pill
		 */
		int getEnergyContents() const {
			return energyContents;
		}
		
		/**
		 * Sets the energy contents of this energy pill
		 *
		 * @param the energy contents of this energy pill
		 */
		void setEnergyContents(int en_cont);
	
		/**
		 * Returns a string representation of this object
		 *
		 * @return a string representation of this object
		 */
		string toString() const;
};

#endif
