/**
 * robot.cpp
 *
 * @author Brian Reber
 *
 * A Robot class, containing all the Robot specific information.
 */
#include "robot.h"
#include "stringutils.h"
#include <iostream>
#include <sstream>

/**
 * Creates a Robot with all the parameters in the given
 * list.
 * 
 * @param params - a list of parameters according to the
 *			given spec.
 */
Robot::Robot(list<string> params) : Object::Object("Robot") {
	color = "blue";
	name = "Object";
	dir = 0;
	energy_contents = 100;
	recharge = 1;
	movecost = 2;
	turncost = 1;
	probecost = 1;
	paramA = .1;
	paramB = 1.6;
	paramC = 1.3;
	setProbable(true);
	setMovable(true);
	
	nameDef = false;
	colorDef = false;
	
	while (!params.empty()) {
		string front = params.front();
		string label = front.substr(0, front.find("="));
		string val = trim(front.substr(front.find("=") + 2));

		if (label.find("color") != string::npos) {
			color = val;
			colorDef = true;
		} else if (label.find("name") != string::npos) {
			name = val;
			nameDef = true;
		} else if (label.find("display") != string::npos) {
			if (val.size() != 2) {
				cerr << "Display attribute must be 2 characters" << endl;
				return;
			}
			
			setDisplay(val);
		} else if (label.find("energy-contents") != string::npos) {
			stringstream ss(val);
			ss >> energy_contents;
		} else if (label.find("recharge") != string::npos) {
			stringstream ss(val);
			ss >> recharge;
		} else if (label.find("movecost") != string::npos) {
			stringstream ss(val);
			ss >> movecost;
		} else if (label.find("turncost") != string::npos) {
			stringstream ss(val);
			ss >> turncost;
		} else if (label.find("probecost") != string::npos) {
			stringstream ss(val);
			ss >> probecost;
		} else if (label.find("paramA") != string::npos) {
			stringstream ss(val);
			ss >> paramA;
		} else if (label.find("paramB") != string::npos) {
			stringstream ss(val);
			ss >> paramB;
		} else if (label.find("paramC") != string::npos) {
			stringstream ss(val);
			ss >> paramC;
		} else if (label.find("xloc") != string::npos) {
			int xloc;
			stringstream ss(val);
			ss >> xloc;
			setXLoc(xloc);
		} else if (label.find("yloc") != string::npos) {
			int yloc;
			stringstream ss(val);
			ss >> yloc;
			setYLoc(yloc);
		}
		
		params.pop_front();
	}
}

/**
 * Sets the direction of this robot
 *
 * @param the direction of this robot
 */
void Robot::setDir(int _dir) {
	dir = _dir;
}

/**
 * Sets the color of this robot
 *
 * @param the color of this robot
 */
void Robot::setColor(string col) {
	color = col;
}

/**
 * Sets the name of this robot
 *
 * @param the name of this robot
 */
void Robot::setName(string nam) {
	name = nam;
}

/**
 * Sets the energy contents of this robot
 *
 * @param the energy contents of this robot
 */
void Robot::setEnergyContents(int en_cont) {
	energy_contents = en_cont;
}

/**
 * Sets the recharge value of this robot
 *
 * @param the recharge value of this robot
 */
void Robot::setRecharge(int rechar) {
	recharge = rechar;
}

/**
 * Sets the cost to move this robot
 *
 * @param the cost to move this robot
 */
void Robot::setMoveCost(int cost) {
	movecost = cost;
}

/**
 * Sets the cost to turn this robot
 *
 * @param the cost to turn this robot
 */
void Robot::setTurnCost(int cost) {
	turncost = cost;
}

/**
 * Sets the cost to probe
 *
 * @param the cost to probe
 */
void Robot::setProbeCost(int cost) {
	probecost = cost;
}

/**
 * Sets the value of paramA
 *
 * @param the value of paramA
 */
void Robot::setParamA(double param) {
	paramA = param;
}

/**
 * Sets the value of paramB
 *
 * @param the value of paramB
 */
void Robot::setParamB(double param) {
	paramB = param;
}

/**
 * Sets the value of paramC
 *
 * @param the value of paramC
 */
void Robot::setParamC(double param) {
	paramC = param;
}

/**
 * Returns a string representation of this object
 *
 * @return a string representation of this object
 */
string Robot::toString() const {
	stringstream str;
	
	str << Object::toString();
	if (nameDef) {
		str << "Name: " << getName() << endl;
	} else {
		str << "Name: " << getDisplay() << endl;
	}
	
	if (colorDef) {
		str << "Color: " << getColor() << endl;
	}
	
	str << "Energy Contents: " << getEnergyContents() << endl;
	
	return str.str();
}
