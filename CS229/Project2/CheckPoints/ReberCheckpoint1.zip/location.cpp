/**
 * object.cpp
 *
 * @author Brian Reber
 *
 * An abstract Object class, containing information applicable to 
 * all types of objects
 */
#include "location.h"
#include <sstream>

/**
 * Sets the whether this object is probable
 *
 * @param prob - whether this object is probable
 */
void Location::setProbable(bool prob) {
	probable = prob;
}

/**
 * Sets the display string of this object
 *
 * @param disp - the display string of this object
 */
void Location::setDisplay(string disp) {
	display = disp;
}

/**
 * Sets the x location of this object
 *
 * @param loc - the x location of this object
 */
void Location::setXLoc(int loc) {
	xloc = loc;
}

/**
 * Sets the y location of this object
 *
 * @param loc - the y location of this object
 */
void Location::setYLoc(int loc) {
	yloc = loc;
}

/**
 * Returns a string representation of this object
 *
 * @return a string representation of this object
 */
string Location::toString() const {
	stringstream str;
	
	str << "Type: " << getType() << endl;
	
	return str.str();
}
