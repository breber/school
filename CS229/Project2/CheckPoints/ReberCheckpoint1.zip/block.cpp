/**
 * block.cpp
 *
 * @author Brian Reber
 *
 * A Block class, containing all the Block specific information.
 */
#include "block.h"
#include "stringutils.h"
#include <iostream>
#include <sstream>

/**
 * Creates a block with all the parameters in the given
 * list.
 * 
 * @param params - a list of parameters according to the
 *			given spec.
 */
Block::Block(list<string> params) : Object::Object("Block") {
	color = "blue";
	name = "Object";
	setProbable(true);
	setMovable(true);
	
	nameDef = false;
	colorDef = false;
	
	while (!params.empty()) {
		string front = params.front();
		string label = front.substr(0, front.find("="));
		string val = trim(front.substr(front.find("=") + 2));

		if (label.find("color") != string::npos) {
			color = val;
			colorDef = true;
		} else if (label.find("name") != string::npos) {
			name = val;
			nameDef = true;
		} else if (label.find("display") != string::npos) {
			if (val.size() != 2) {
				cerr << "Display attribute must be 2 characters" << endl;
				return;
			}
			
			setDisplay(val);
		} else if (label.find("xloc") != string::npos) {
			int xloc;
			stringstream ss(val);
			ss >> xloc;
			setXLoc(xloc);
		} else if (label.find("yloc") != string::npos) {
			int yloc;
			stringstream ss(val);
			ss >> yloc;
			setYLoc(yloc);
		}
		
		params.pop_front();
	}
}

/**
 * Sets the color of this block
 *
 * @param the color of this block
 */
void Block::setColor(string col) {
	color = col;
}

/**
 * Sets the name of this block
 *
 * @param the name of this block
 */
void Block::setName(string nam) {
	name = nam;
}

/**
 * Returns a string representation of this object
 *
 * @return a string representation of this object
 */
string Block::toString() const {
	stringstream str;
	
	str << Object::toString();
	if (nameDef) {
		str << "Name: " << getName() << endl;
	} else {
		str << "Name: " << getDisplay() << endl;
	}
	
	if (colorDef) {
		str << "Color: " << getColor() << endl;
	}
	
	return str.str();
}
