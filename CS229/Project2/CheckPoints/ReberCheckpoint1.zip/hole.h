/**
 * hole.h
 *
 * @author Brian Reber
 *
 * A Hole class, containing all the Hole specific information.
 */
#ifndef HOLE_H
#define HOLE_H

#include <string>
#include "property.h"
#include <list>

using namespace std;

class Hole : public Property {
	private:
		string name;
	
		bool nameDef;
	public: 
		/**
		 * Creates a hole with all the parameters in the given
		 * list.
		 * 
		 * @param params - a list of parameters according to the
		 *			given spec.
		 */
		Hole(list<string> params);
	
		/**
		 * Gets the name of this hole
		 *
		 * @return the name of this hole
		 */
		string getName() const {
			return name;
		}
		
		/**
		 * Sets the name of this hole
		 *
		 * @param the name of this hole
		 */
		void setName(string nam);
	
		/**
		 * Returns a string representation of this object
		 *
		 * @return a string representation of this object
		 */
		string toString() const;
};

#endif
