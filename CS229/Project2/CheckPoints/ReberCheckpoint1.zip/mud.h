/**
 * mud.h
 *
 * @author Brian Reber
 *
 * A Mud class, containing all the Mud specific information.
 */
#ifndef MUD_H
#define MUD_H

#include <string>
#include "property.h"
#include <list>

using namespace std;

class Mud : public Property {
	private:
		string name;
		int energyCost;
		int turnCost;
	
		bool nameDef;
	public: 
		/**
		 * Creates a mud with all the parameters in the given
		 * list.
		 * 
		 * @param params - a list of parameters according to the
		 *			given spec.
		 */
		Mud(list<string> params);
	
		/**
		 * Gets the name of this mud
		 *
		 * @return the name of this mud
		 */
		string getName() const {
			return name;
		}
		
		/**
		 * Sets the name of this mud
		 *
		 * @param the name of this mud
		 */
		void setName(string nam);
	
		/**
		 * Gets the energy cost of this mud
		 *
		 * @return the energy cost of this mud
		 */
		int getEnergyCost() const {
			return energyCost;
		}
		
		/**
		 * Sets the energy cost of this mud
		 *
		 * @param the energy cost of this mud
		 */
		void setEnergyCost(int en_cost);
	
		/**
		 * Gets the turn cost of this mud
		 *
		 * @return the turn cost of this mud
		 */
		int getTurnCost() const {
			return turnCost;
		}
		
		/**
		 * Sets the turn cost of this mud
		 *
		 * @param the turn cost of this mud
		 */
		void setTurnCost(int turn_cost);
	
		/**
		 * Returns a string representation of this object
		 *
		 * @return a string representation of this object
		 */
		string toString() const;
};

#endif
