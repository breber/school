/**
 * property.h
 *
 * @author Brian Reber
 *
 * An abstract Property class, containing information applicable to 
 * all types of Properties
 */
#ifndef PROPERTY_H
#define PROPERTY_H

#include <string>
#include "location.h"

using namespace std;

class Property : public Location {
	public: 
		/**
		 * Creates a lava with all the parameters in the given
		 * list.
		 */
		Property(string type);
	
		/**
		 * Provice a virtual Deconstructor to allow for the virtual method
		 */
		virtual ~Property() {	}
	
		/**
		 * Returns a string representation of this property
		 *
		 * @return a string representation of this property
		 */
		virtual string toString() const;
};

#endif
