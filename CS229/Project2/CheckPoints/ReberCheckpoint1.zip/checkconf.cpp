/**
 * checkconf.cpp
 *
 * @author Brian Reber
 *
 * A runner for parsing the config file
 */
#include "checkconf.h"
#include "stringutils.h"
#include <vector>
#include <fstream>
#include <iostream>

int main(int argc, char *argv[]) {
	vector<Object *> objects;
	vector<Property *> properties;
	queue<string> vals;
	
	Simulation currentSim;
	ifstream file;
	string temp;
	
	if (argc == 2) {
		file.open(argv[1]);
	} else {
		cerr << "Missing command line argument" << endl;
		return 0;
	}
	
	while (!file.eof()) {
		getline(file, temp);
		string noComments = removeComments(temp);
		if (noComments.size() > 0) {
			vals.push(noComments);
		}
	}
	
	file.close();
	
	parseSimulation(&currentSim, &vals);
	
	while (!vals.empty()) {
		if (toUpperCase(vals.front()).find("<OBJECT>") != string::npos) {
			objects.push_back(parseObject(&vals));
		} else if (toUpperCase(vals.front()).find("<PROPERTY>") != string::npos) {
			properties.push_back(parseProperty(&vals));
		}
	}
	
	for (unsigned int i = 0; i < objects.size(); i++) {
		currentSim.addObject(objects[i]);
	}
	for (unsigned int i = 0; i < properties.size(); i++) {
		currentSim.addProperty(properties[i]);
	}
	
	// Print the Board and the information about occupied locations
	cout << currentSim.toString() << endl;
	cout << currentSim.printObjectData();
	
	return 0;
}
