/**
 * pilladdict.cpp
 *
 * @author Brian Reber
 *
 * A robot brain that navigates the simulation in order to find pills
 */
#include "pilladdict.h"
#include <iostream>

int main(int argc, char *argv[]) {
	string temp;
	int messageCode = -1;

	Brain *pill = new PillAddict();

	vector<Location *> objectsSeen;
	
	int numTurnsCompleted = 0;
	int probed = 0;
	
	while (true) {
		cin >> messageCode;
		
		switch (messageCode) {
			// Initialization
			case 0: {
				pill->parseInitialization();
				break;
			}
			// Move Request
			case 1: {
				int distances[probed];
				
				string success;
				cin >> success;
				
				pill->parseMoveRequest(&objectsSeen, distances, probed, numTurnsCompleted);
								
				numTurnsCompleted++;
				pill->makeMoveDecision(objectsSeen, &probed, distances);
				
				break;				
			} 
			// Termination request
			case 2: {
				return 0;
			}
			default:
				break;
		}
		messageCode = 0;
	}
	
	return 0;
}

/**
 * Given the robot's current position, and its surroundings, we make a decision about
 * what the robot should do on the next turn.
 *
 * @param objectsSeen - a list of the objects in the 8 surrounding locations
 * @param *probeWidth - the width of the probe in the previous turn. Needs to be
 *				re-written each turn so that it is always updated
 * @param distances[] - an array of distances of probable objects probed on the last turn.
 *				The size of this array is probeWidth.
 */
void PillAddict::makeMoveDecision(vector<Location *> objectsSeen, int *probeWidth, int distances[]) {
	
	static int numTurnsLeftForAction = 0;
	static queue<func> funcPoint;
	
	(*probeWidth) = 0;
	
	// If there are actions that we still need to complete, do those
	// first before starting to do other things
	if (funcPoint.size() > 0) {
		func toCall = funcPoint.front();
		funcPoint.pop();
		
		(this->*toCall)();
		
		numTurnsLeftForAction--;
		return;
	}
	
	if (objectsSeen.size() > 0) {
		// We can see objects, so we will see if there are any
		// energy pills around us.  If so, we will definitely want
		// to pick them up.
		for (unsigned int i = 0; i < objectsSeen.size(); i++) {
			if (objectsSeen[i]->getConfigType() == "energy-pill") {
				numTurnsLeftForAction = turnTowardsPill(objectsSeen[i]->getXLoc(), objectsSeen[i]->getYLoc(), funcPoint);
			}
		}
	}
	
}

int PillAddict::turnTowardsPill(int xloc, int yloc, queue<func> &funcPoint) {
	if (yloc == robot->getYLoc() && xloc == (robot->getXLoc() + 1) && robot->getDir() != EAST) {
		// To the right
		rotate(90);
	} else if (yloc == robot->getYLoc() && xloc == (robot->getXLoc() - 1) && robot->getDir() != WEST) {
		// To the left
		rotate(-90);
	} else if (yloc == (robot->getYLoc() + 1) && xloc == robot->getXLoc() && robot->getDir() != SOUTH) {
		// Below
		rotate(-90);
		funcPoint.push(&PillAddict::rotateN90);
		funcPoint.push(&PillAddict::moveForward);
		return 1;
	}
	
	
	return 0;
}
