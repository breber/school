/**
 * simulate.h
 *
 * @author Brian Reber
 *
 * The simulation that gets run and interacts with the robot brains
 */
#ifndef SIMULATE_H
#define SIMULATE_H

#include <fstream>
#include "stringutils.h"

using namespace std;

#define SUCCESS_STR "true "
#define FAIL_STR "false "
#define NONE_STR "null "

enum SuccessParam {
	SUCCESS,
	FAIL,
	NONE
};

class RobotIO {
	public:
		FILE * inFile;
		FILE * outFile;
		Robot * bot;
		int probed;
		int * probe;
		SuccessParam successParam;
};

/**
 * Sends the initialization request to the given robot's output file
 *
 * @param robot - the robot to send the commands to
 * @param currentSim - the simulation currently running
 * @param numRobots - the number of robots in the simulation
 */
void sendInitializationRequest(RobotIO &robot, Simulation &currentSim, int numRobots);

/**
 * Sends a move request to the given robot's output file
 *
 * @param robot - the robot to send the commands to
 * @param currentSim - the simulation currently running
 * @param turnNum - the current turn
 */
void sendMoveRequest(RobotIO &robot, Simulation &currentSim, int turnNum);

/**
 * Receives a move decision command from the robot's input file
 *
 * @param robot - the robot to read the commands from
 * @param currentSim - the simulation currently running
 */
void receiveMoveDecision(RobotIO &robot, Simulation &currentSim);

#endif
