/**
 * simulate.cpp
 *
 * @author Brian Reber
 *
 * The simulation that gets run and interacts with the robot brains
 */
#include "simulate.h"
#include "brain.h"
#include "energy.h"
#include <iostream>
#include <sstream>

int main(int argc, char *argv[]) {
	Simulation currentSim;
	ifstream file;
	string mode;
	int turnNum = 0, numTurns = 0;
	int numRobots = 0;
	
	// Files for communicating with robots
	vector<RobotIO> robots;
		
	if (argc >= 3) {
		// Config file
		file.open(argv[1]);
		
		if (!file.is_open()) {
			cerr << "Invalid config file location" << endl;
			return 0;
		}
		
		// number of turns
		stringstream ss(argv[2]);
		ss >> numTurns;

		// quiet or verbose
		mode = argv[3];
		
		// Open the file descriptors
		int i = 4, num = 0;
		while (i < argc) {
			int fd;
			
			sscanf(argv[i], "%d", &fd);
			
			if ((i % 2) == 0) {
				RobotIO temp;
				robots.push_back(temp);
				
				robots[num].outFile = fdopen(fd, "w");
			} else {
				robots[num++].inFile = fdopen(fd, "r");
			}
						
			i++;
		}
		
	} else {
		cerr << "Missing command line argument" << endl;
		return 0;
	}
	
	parseConfigFile(file, &currentSim);
	
	// Get a list of all the robots in the simulation
	vector<Object *> objs = currentSim.getObjects();
	for (unsigned int i = 0, count = 0; i < objs.size(); i++) {
		if (objs[i]->getType() == "Robot") {
			numRobots++;
			robots[count].bot = ((Robot *) objs[i]);
			robots[count].successParam = NONE;
			robots[count].probed = 0;
			count++;
		}
	}
		
	// START COMMUNICATION BY INITIALIZING
	for (unsigned int i = 0; i < robots.size(); i++) {
		sendInitializationRequest(robots[i], currentSim, numRobots);
	}
	
	while (turnNum < numTurns) {
		// SEND MOVE REQUEST
		for (unsigned int i = 0; i < robots.size(); i++) {
			sendMoveRequest(robots[i], currentSim, turnNum);
		}
		
		// RECEIVE MOVE DECISION
		for (unsigned int i = 0; i < robots.size(); i++) {
			receiveMoveDecision(robots[i], currentSim);
		}
		
		// After every robot has had a turn, we recharge the robots
		for (unsigned int i = 0; i < robots.size(); i++) {
			robots[i].bot->recharge();
		}
		
		// If we are in verbose mode, print out the board
		if (mode == "-verbose") {
			cout << currentSim.toString() << endl;

			// Wait for the user to press a button
			cin.get();
		}
		
		turnNum++;
	}
	
	// SEND TERMINATION REQUEST
	for (unsigned int i = 0; i < robots.size(); i++) {
		fprintf(robots[i].outFile, "2 ");
		fflush(robots[i].outFile);
	}
	
	// Print the Board and the information about occupied locations
	cout << currentSim.toString() << endl;
	cout << currentSim.printObjectData();
	
	return 0;
}

/**
 * Sends the initialization request to the given robot's output file
 *
 * @param robot - the robot to send the commands to
 * @param currentSim - the simulation currently running
 * @param numRobots - the number of robots in the simulation
 */
void sendInitializationRequest(RobotIO &robot, Simulation &currentSim, int numRobots) {
	fprintf(robot.outFile, "0 ");
	fprintf(robot.outFile, "%d ", robot.bot->getEnergyContents());
	fprintf(robot.outFile, "%d ", robot.bot->getXLoc());
	fprintf(robot.outFile, "%d ", robot.bot->getYLoc());
	fprintf(robot.outFile, "%s ", robot.bot->getColor().c_str());
	fprintf(robot.outFile, "%d ", currentSim.getHeight());
	fprintf(robot.outFile, "%d ", currentSim.getWidth());
	fprintf(robot.outFile, "%d ", numRobots);
	fflush(robot.outFile);
}

/**
 * Sends a move request to the given robot's output file
 *
 * @param robot - the robot to send the commands to
 * @param currentSim - the simulation currently running
 * @param turnNum - the current turn
 */
void sendMoveRequest(RobotIO &robot, Simulation &currentSim, int turnNum) {
	fprintf(robot.outFile, "1 ");
	
	// Success param			
	if (robot.successParam == SUCCESS) {
		fprintf(robot.outFile, SUCCESS_STR);
	} else if (robot.successParam == FAIL) {
		fprintf(robot.outFile, FAIL_STR);
	} else if (robot.successParam == NONE) {
		fprintf(robot.outFile, NONE_STR);
	}
		
	// Number of seen items
	vector<Location *> seen = currentSim.getSeenItems(robot.bot->getXLoc(), robot.bot->getYLoc());
	fprintf(robot.outFile, "%d ", (int) seen.size());
		
	// Seen item details
	for (unsigned int j = 0; j < seen.size(); j++) {
		fprintf(robot.outFile, "%s ", seen[j]->getConfigType().c_str());
		fprintf(robot.outFile, "%d ", seen[j]->getXLoc());
		fprintf(robot.outFile, "%d ", seen[j]->getYLoc());
		if (seen[j]->isObject()) {
			fprintf(robot.outFile, "%s ", ((Object *) seen[j])->getColor().c_str());
		}
		if (Brain::hasEnergy(seen[j]->getType())) {
			fprintf(robot.outFile, "%d ", ((IEnergy *) seen[j])->getEnergy());
		}
	}
		
	// If the robot probed last turn, we return their results
	if (robot.probed > 0) {
		for (int i = 0; i < robot.probed; i++) {
			fprintf(robot.outFile, "%d ", robot.probe[i]);
		}
	}
	
	// If we are on a turn we need to return energy, we do so
	if ((turnNum % 5) == 0) {
		fprintf(robot.outFile, "%d ", robot.bot->getEnergy());
	}
		
	fflush(robot.outFile);
}

/**
 * Receives a move decision command from the robot's input file
 *
 * @param robot - the robot to read the commands from
 * @param currentSim - the simulation currently running
 */
void receiveMoveDecision(RobotIO &robot, Simulation &currentSim) {
	int actionCode = -1;
	
	// TODO: ALL ROBOTS NOT MOVE AT SAME TIME
	
	fscanf(robot.inFile, "%d", &actionCode);
	
	robot.probed = false;
	
	switch (actionCode) {
		case 0: {
			cout << "FORWARD" << endl;
			// Move forward			
			if (robot.bot->getEnergy() >= robot.bot->getMoveCost()) {
				try {
					robot.bot->moveForward(currentSim.getWidth(), currentSim.getHeight());
				} catch (char const*s) {
					cerr << "CAUGHT AN EXCEPTION" << endl;
					robot.successParam = FAIL;
				}
				robot.bot->setEnergyContents(robot.bot->getEnergy() - robot.bot->getMoveCost());
				robot.successParam = SUCCESS;
			} else {
				// If we didn't have enough energy, set the success param to FAIL
				robot.successParam = FAIL;
			}
			
			currentSim.updateObject(robot.bot, true);
			
			break;	
		} case 1: {
			// turn
			char degrees[5];
			fscanf(robot.inFile, "%s", degrees);
			
			// If we have enough energy (turn cost), we will turn
			if (robot.bot->getEnergy() >= robot.bot->getTurnCost()) {
				if (strcmp("-90", degrees) == 0) {
					robot.bot->setDir(robot.bot->getDir() + 270);
				} else if (strcmp("+90", degrees) == 0) {
					robot.bot->setDir(robot.bot->getDir() + 90);
				} else {
					cerr << "Improper direction" << endl;
					robot.successParam = FAIL;
					return;
				}
				
				robot.bot->setEnergyContents(robot.bot->getEnergy() - robot.bot->getTurnCost());
				robot.successParam = SUCCESS;
			} else {
				// If we didn't have enough energy, set the success param to FAIL
				robot.successParam = FAIL;
			}
			
			break;
		} case 2: {
			// Fire
			int energy;
			fscanf(robot.inFile, "%d", &energy);
			
			cout << "SIMULATE - fire" << endl;
			
			// If we have enough energy (fire cost), we will fire
			if (robot.bot->getEnergy() >= robot.bot->getFireCost(energy)) {
				// TODO
				
				robot.bot->setEnergyContents(robot.bot->getEnergy() - robot.bot->getFireCost(energy));
				robot.successParam = SUCCESS;
			} else {
				// If we didn't have enough energy, set the success param to FAIL
				robot.successParam = FAIL;
			}
			
			break;
		} case 3: {
			// Probe
			int probeWidth;
			fscanf(robot.inFile, "%d", &probeWidth);
	
			// If we have enough energy (probe cost * number of beams), 
			// we will probe
			if (robot.bot->getEnergy() >= (robot.bot->getProbeCost() * probeWidth)) {
				robot.probed = probeWidth;
				robot.probe = currentSim.probe(robot.bot->getXLoc(), robot.bot->getYLoc(), robot.bot->getDir(), probeWidth);
				robot.bot->setEnergyContents(robot.bot->getEnergy() - (robot.bot->getProbeCost() * probeWidth));
				robot.successParam = SUCCESS;
			} else {
				// If we didn't have enough energy, set the success param to FAIL
				robot.successParam = FAIL;
			}
			break;
		} case 4: {
			// Do nothing
			robot.successParam = NONE;
			break;
		} default: {
			cerr << "Improper Action Code" << endl;
			break;
		}
	}
}
