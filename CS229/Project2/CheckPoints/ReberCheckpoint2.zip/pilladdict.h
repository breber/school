/**
 * pilladdict.h
 *
 * @author Brian Reber
 *
 * A robot brain that navigates the simulation in order to find pills
 */
#ifndef PILLADDICT_H
#define PILLADDICT_H

#include "brain.h"
#include <iostream>

using namespace std;

class PillAddict : public Brain {
	typedef void (PillAddict::*func)();
	public:
		virtual ~PillAddict() { }
	
		/**
		 * Given the robot's current position, and its surroundings, we make a decision about
		 * what the robot should do on the next turn.
		 *
		 * @param objectsSeen - a list of the objects in the 8 surrounding locations
		 * @param *probeWidth - the width of the probe in the previous turn. Needs to be
		 *				re-written each turn so that it is always updated
		 * @param distances[] - an array of distances of probable objects probed on the last turn.
		 *				The size of this array is probeWidth.
		 */
		virtual void makeMoveDecision(vector<Location *> objectsSeen, int *probeWidth, int distances[]);
	
		int turnTowardsPill(int xloc, int yloc, queue<func> &funcPoint);
	
		void rotate90() {
			rotate(90);
		}
	
		void rotateN90() {
			rotate(-90);
		}
};

#endif
