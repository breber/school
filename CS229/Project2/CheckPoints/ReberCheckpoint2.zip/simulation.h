/**
 * simulation.h
 *
 * @author Brian Reber
 *
 * An class representing the simulation board
 */
#ifndef SIMULATION_H
#define SIMULATION_H

#include "object.h"
#include "property.h"
#include <vector>

using namespace std;

class Simulation {
	private:
		bool initializedObjects;
		int width;
		int height;
		Object ***objects;
		vector<Property *> **properties;
		
		/**
		 * Initializes the object and property arrays
		 */
		void initializeArrays();
	public: 
		/**
		 * Creates a new default simulation
		 */
		Simulation();
		
//		~Simulation();
	
		/**
		 * Sets the width of the simulation board
		 *
		 * @param _width - the width of the simulation board
		 */
		void setWidth(int _width);

		/**
		 * Gets the width of the simulation board
		 *
		 * @return the width of the simulation board
		 */
		int getWidth() const {
			return width;
		}
	
		/**
		 * Sets the height of the simulation board
		 *
		 * @param _height - the height of the simulation board
		 */
		void setHeight(int _height);
	
		/**
		 * Gets the height of the simulation board
		 *
		 * @return the height of the simulation board
		 */
		int getHeight() const {
			return height;
		}
	
		/**
		 * Adds the given object to this simulation
		 *
		 * @param the object to add
		 */
		void addObject(Object *obj);
	
		/**
		 * Removes the given object to this simulation
		 *
		 * @param the object to remove
		 */
		void removeObject(Object *obj);
	
		/**
		 * Updates the given object in this simulation
		 *
		 * @param the object to update
		 */
		void updateObject(Object *obj, bool hasEnergy);
	
		/**
		 * Adds the given property to this simulation
		 *
		 * @param the property to add
		 */
		void addProperty(Property *prop);
	
		/**
		 * Gets a list of objects
		 *
		 * @return the object currently in the simulation
		 */
		const vector<Object *> getObjects() const;
	
		/**
		 * Gets a list of properties
		 *
		 * @return the object currently in the simulation
		 */
		const vector< vector<Property *> > getProperties() const;
	
		/**
		 * Gets a list of items that can be seen at the given location
		 *
		 * @param xloc - the x location to look at
		 * @param yloc - the y location to look at
		 * @return list of items that can be seen at the given location
		 */
		const vector <Location *> getSeenItems(int xloc, int yloc) const;
	
		int * probe(int xloc, int yloc, int dir, int probeWidth) const;
	
		/**
		 * Gets the configuration string for this simulation
		 *
		 * @return the string representation of this simulation's configuration data
		 */
		string getConfString() const;
	
		/**
		 * Prints out the necessary object data
		 *
		 * @return the string representation of all the objects in the simulation
		 */
		string printObjectData() const;
	
		/**
		 * Returns a string representation of this simulation
		 *
		 * @param a string representation of this simulation
		 */
		string toString() const;
};

#endif
