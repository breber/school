/**
 * checkconf.cpp
 *
 * @author Brian Reber
 *
 * A runner for parsing the config file
 */
#include "checkconf.h"
#include "stringutils.h"
#include <vector>
#include <fstream>
#include <iostream>

int main(int argc, char *argv[]) {
	vector<Object *> objects;
	vector<Property *> properties;
	queue<string> vals;
	
	Simulation currentSim;
	ifstream file;
	string temp;
	
	if (argc == 2) {
		file.open(argv[1]);
		
		if (!file.is_open()) {
			cerr << "Invalid config file location" << endl;
			return 0;
		}
	} else {
		cerr << "Missing command line argument" << endl;
		return 0;
	}

	parseConfigFile(file, &currentSim);
	
	// Print the Board and the information about occupied locations
	cout << currentSim.toString() << endl;
	cout << currentSim.printObjectData();
	
	return 0;
}
