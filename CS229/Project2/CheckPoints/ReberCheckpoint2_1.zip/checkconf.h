/**
 * checkconf.cpp
 *
 * @author Brian Reber
 *
 * A runner for parsing the config file
 */
#ifndef CHECKCONF_H
#define CHECKCONF_H

using namespace std;

#endif
